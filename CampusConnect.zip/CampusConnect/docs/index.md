site_name: MkLorum
nav:
  - Home: index.md
  - About: about.md
  - Development: index.md
theme: readthedocs